extends Node3D

@onready var xr_root: XROrigin3D = $XRRoot
@onready var left_controller: XRController3D = $XRRoot/LeftHand
@onready var right_controller: XRController3D = $XRRoot/RightHand
@onready var hud: Label3D = $HUD

var xr_interface: XRInterface
var previous_hand_positions: Dictionary = {}
var grip_was_down: Dictionary = {"left": false, "right": false}
var ready_for_xr := false

func _ready() -> void:
    # Keep a visible fallback message if OpenXR cannot initialise.
    xr_interface = XRServer.find_interface("OpenXR")
    if xr_interface == null:
        hud.text = "GRIP TEST\nOpenXR interface not found."
        push_warning("OpenXR interface not found. Check Android OpenXR export settings.")
        return

    if xr_interface.is_initialized():
        _enable_xr()
    else:
        ready_for_xr = xr_interface.initialize()
        if ready_for_xr:
            _enable_xr()
        else:
            hud.text = "GRIP TEST\nOpenXR did not initialise.\nEnable OpenXR for Android export."
            push_warning("OpenXR failed to initialise.")

func _enable_xr() -> void:
    get_viewport().use_xr = true
    hud.text = "GRIP TEST\nHold Grip near a block, then push your hand away.\nThumbstick locomotion is also enabled."

func _process(delta: float) -> void:
    if not ready_for_xr and (xr_interface == null or not xr_interface.is_initialized()):
        return
    _thumbstick_move(delta)
    _grip_push(left_controller, "left")
    _grip_push(right_controller, "right")

func _thumbstick_move(delta: float) -> void:
    # Fallback locomotion for comfort and for moving away from awkward surfaces.
    var move := Vector2.ZERO
    if left_controller:
        move = left_controller.get_vector2("primary")
    if move.length() < 0.15:
        return
    var head_basis := $XRRoot/XRCamera3D.global_transform.basis
    var forward := -head_basis.z
    forward.y = 0.0
    forward = forward.normalized()
    var right := head_basis.x
    right.y = 0.0
    right = right.normalized()
    xr_root.global_position += (right * move.x + forward * move.y) * delta * 2.0

func _grip_push(controller: XRController3D, side: String) -> void:
    if controller == null or not controller.is_active():
        previous_hand_positions.erase(side)
        grip_was_down[side] = false
        return

    var hand_position: Vector3 = controller.global_position
    var grip_down := controller.is_button_pressed("grip") or controller.is_button_pressed("trigger")
    var touching := _near_block(hand_position, 0.28)

    if grip_down and bool(grip_was_down[side]) and touching and previous_hand_positions.has(side):
        var old_position: Vector3 = previous_hand_positions[side]
        var hand_delta := hand_position - old_position
        # Move the player opposite the hand motion, like pushing against a wall.
        if hand_delta.length() < 0.18:
            xr_root.global_position -= hand_delta
    previous_hand_positions[side] = hand_position
    grip_was_down[side] = grip_down

func _near_block(point: Vector3, radius: float) -> bool:
    for body in get_tree().get_nodes_in_group("grip_surfaces"):
        if body is Node3D:
            var distance := body.global_position.distance_to(point)
            if distance < radius + 0.9:
                return true
    return false
