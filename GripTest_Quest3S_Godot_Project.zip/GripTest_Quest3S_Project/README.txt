GRIP TEST — Meta Quest 3S starter project
==========================================

This is a Godot project source package, not a precompiled APK. It is designed as a standalone OpenXR starting point for Quest 3S. I cannot honestly claim it has been built or headset-tested in this environment.

PROJECT FILES
- project.godot
- scenes/main.tscn
- scripts/grip_test.gd

BUILD ROUTE (no PC required if using Godot XR Editor on the headset)
1. Install the official Godot XR Editor for Meta Quest from the Godot download page / Meta Horizon Store.
2. Extract this ZIP into a folder the XR Editor can access.
3. Open/import the folder as a Godot project.
4. In Project > Export, create an Android export preset.
5. Set XR Mode to OpenXR and use the Compatibility / OpenGL renderer.
6. If using the Gradle build option, install the Godot Android Build Environment app when prompted.
7. Export the APK, install it, then launch Grip Test from Unknown Sources.

If you have access to a PC, you can use Godot 4.6+ plus Android Studio/OpenJDK 17, configure the Android SDK, and export the APK from the desktop editor instead.

IMPORTANT LIMITATIONS
- This starter project requires validation in the Godot editor. It is not a compiled APK.
- Godot XR Editor is an official way to create/export projects on Quest devices, but the editor and Android build environment may need to be installed separately.
- If the OpenXR runtime fails to initialize, check the Android export preset's XR Mode = OpenXR and ensure the project is exported for Android.
- The controller interaction is a first-pass prototype; controller action names can vary with OpenXR action-map configuration and may need adjustment after the first on-headset test.

Official references:
Godot Android XR deployment docs:
https://docs.godotengine.org/en/4.6/tutorials/xr/deploying_to_android.html
Godot XR Editor:
https://docs.godotengine.org/en/latest/tutorials/editor/using_the_xr_editor.html
Meta Quest 3S / Unity OpenXR support:
https://developers.meta.com/vr/documentation/unity/unity-openxr-settings-quest/
